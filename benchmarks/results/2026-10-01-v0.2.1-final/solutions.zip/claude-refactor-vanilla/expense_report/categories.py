"""Shared category helpers."""


def normalize_category(value):
    return value.strip().casefold()
