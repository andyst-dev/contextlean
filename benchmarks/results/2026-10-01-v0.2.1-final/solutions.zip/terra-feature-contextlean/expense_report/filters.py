def normalize_category(value):
    return value.strip().casefold()


def select_category(expenses, category):
    if category is None:
        return list(expenses)
    return [
        expense for expense in expenses
        if normalize_category(expense["category"]) == category
    ]


def select_min_amount(expenses, minimum):
    if minimum is None:
        return list(expenses)
    return [expense for expense in expenses if expense["amount"] >= minimum]
