def normalize_category(value):
    return value.strip().casefold()


def select_category(expenses, category):
    return select_expenses(expenses, category=category)


def select_expenses(expenses, category=None, min_amount=None):
    return [
        expense
        for expense in expenses
        if (category is None or normalize_category(expense["category"]) == category)
        and (min_amount is None or expense["amount"] >= min_amount)
    ]
