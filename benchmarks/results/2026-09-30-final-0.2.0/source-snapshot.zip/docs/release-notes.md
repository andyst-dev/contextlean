# ContextLean 0.2.0 — unreleased

Both manifests and the measurement helper identify 0.2.0. This draft remains
unreleased until the owner approves tagging and publication.
[Pre-commit verification and known limits](verification.md).

- Beginner onboarding explains repository instructions, context and tokens, shows
  what bootstrap creates, and gives a five-step usage guide with a conceptual visual.
- A shared local catalog supports two-command Codex installation. Fresh Codex and
  Claude discovery exposes all four shared skills. UI prompts use qualified installed
  names, resolving the bootstrap invocation ambiguity.
- The existing bootstrap workflow remains explicit and preserves repository guidance;
  documentation explains the project map, shared Claude import and local static reports.
  Audit and review remain read-only unless their narrow fixes are separately requested.
- A dependency-free, independently graded sample suite covers navigation, bug fixes,
  features, refactors and documentation/configuration. It preserves raw outcomes,
  restores original tests and checks task acceptance in separate evaluation copies.
- Public preliminary evidence retains all ten existing gpt-5.6-terra/low runs,
  including two token regressions, exact source files, solutions, diagnostics and
  calculations. One run per condition per task cannot establish statistical confidence
  or universal savings. Historical measurements retain their recorded 0.1.0 version.
- Measurement fixes distinguish turn completion from task success, keep unavailable
  fields null, avoid double-counting cached/reasoning tokens and suppress unsupported
  gain/confidence claims. Generated metadata and caches are excluded from future copies.
- Offline CI checks package/skill contracts, parsers, grading, published evidence,
  lint and formatting. The product/tests retain standard-library-only dependencies.
- ContextLean's own audit and lean review checked ownership, startup context,
  documentation, exclusions and unnecessary complexity; the snapshot hygiene issue
  was fixed without repeating bootstrap.

There is still no MCP server, hook, telemetry, runtime package or automatic model run.
Known limits include unverified full independent live skill workflows on both agents,
Claude import consumption, remote CI and clean committed-revision installation.
Benchmark CLI warnings/recovered errors remain visible. No additional model runs
were started during release preparation.
