# ContextLean 0.2.0 verification

Local candidate checked on 2026-09-30. Both manifests and the current measurement
helper identify **0.2.0**. The historical validation dataset keeps its recorded
0.1.0 version. This is the pre-commit verification record; subsequent release-gate
checks cover the committed revision, push and remote CI. No tag or release is created
by this record.

The later [semantic preservation repair](bootstrap-coverage.md) adds the original-rule
coverage matrix, transfer/safe-removal checks and new deterministic verification.
This earlier record remains historical; its test count and remote-check limitations
describe the candidate before that repair.

## Installation and discovery

Tests used a copied checkout, a fresh temporary target project, and empty temporary
Codex/Claude configuration directories. They used the installed CLIs; this is not a
clean-machine download test. Codex can still discover machine-wide/user skills;
verification selected the four ContextLean entries from the new plugin cache.

| Check | Result |
|---|---|
| Codex CLI 0.147.0: `codex plugin marketplace add .`, then `codex plugin add contextlean@contextlean-local` | PASS; cached plugin version 0.2.0 |
| Codex app-server `skills/list`, from the fresh target project | PASS; four enabled ContextLean skills, no discovery errors; metadata below |
| Claude Code 2.1.233: `claude --plugin-dir /path/to/contextlean plugin details contextlean` | PASS; 0.2.0, four skills, zero agents/hooks/MCP/LSP |
| Bundled Codex plugin-creator `scripts/validate_plugin.py` | PASS; manifest and skill metadata |
| Official skill-creator `scripts/quick_validate.py` | PASS for all four skill directories |
| `claude plugin validate .claude-plugin/plugin.json` | PASS; expected plugin-root CLAUDE.md warning |
| `claude plugin validate .claude-plugin/marketplace.json` | PASS; expected unknown Codex `policy` warning; Claude ignores that field |

Discovery returned this compact inventory (not a model-session transcript):

| UI name | Codex installed name | Claude command |
|---|---|---|
| Bootstrap Repository | `contextlean:bootstrap` | `/contextlean:bootstrap` |
| Audit Context Locality | `contextlean:audit` | `/contextlean:audit` |
| Lean Change Review | `contextlean:lean-review` | `/contextlean:lean-review` |
| Benchmark Context Usage | `contextlean:benchmark` | `/contextlean:benchmark` |

In Codex CLI, use `/skills` or type `$` and select the installed skill. UI default
prompts now reference the qualified installed name. `$bootstrap` alone is ambiguous.
[Official skill selection guidance](https://learn.chatgpt.com/docs/build-skills).
Codex installation takes **two commands** from an obtained checkout. The README
has five usage steps; Claude session loading takes one launch command after entering
the target project. Agent installation/authentication and Python 3.11+ are prerequisites.

The catalog uses a shared Claude-compatible local source and Codex policy metadata;
no duplicate catalog or always-loaded wrapper was added. With this catalog,
`claude plugin validate .` selects the marketplace, so verify both explicit paths.
The root `CLAUDE.md` is contributor guidance, not injected plugin context. Bootstrap
creates a wrapper in the user's project. Codex caches the plugin; reinstall after
editing it and start a fresh session. Claude `--plugin-dir` loads that session only.

No paid model session was started during these installation checks. Independent
full live bootstrap/audit/review invocation on both CLIs and Claude's consumption of
the project import remain unverified. Earlier procedure checks and static wrappers
are separate evidence; discovery alone does not establish model behavior.

### Optional development validators

When the bundled validator files and temporary PyYAML dependency are available:

```sh
python3 /path/to/plugin-creator/scripts/validate_plugin.py .
python3 /path/to/skill-creator/scripts/quick_validate.py skills/bootstrap
claude plugin validate .claude-plugin/plugin.json
claude plugin validate .claude-plugin/marketplace.json
```

Repeat the skill validator for audit, lean-review and benchmark. The Codex validator
was obtained from the installed CLI's bundled system skill in a temporary home.
These are verified script interfaces, not an invented `codex plugin validate` command.
They are optional development checks, not beginner installation prerequisites.

## Quality and deterministic CI

- Full standard-library test suite: **58 tests pass** locally on Python 3.14.4.
- Ruff **0.15.7** lint and format check pass; whitespace check passes.
- Public links, cross-platform packaging, skill frontmatter/metadata, explicit
  bootstrap policy and no-MCP/no-hooks contracts are checked by tests.
- Benchmark tests check event parsing, usage arithmetic, unavailable fields,
  suppression of ungraded gain claims, isolation, original-test restoration and grading.
- Public evidence tests check checksums, archive paths, frozen source/fixture/prompt/
  evaluator hashes, all ten recorded usage/command counts, negative cases and saved
  solutions. Regrading runs only local Python tests, with no model calls.
- [Quality CI](../.github/workflows/quality.yml) runs tests, Ruff and formatting on
  Python **3.11 and 3.14**, with read-only repository permission. No live benchmark
  command or provider authentication is part of CI. Python 3.11 and remote Actions
  execution remain unverified locally; the workflow can run after the owner commits/pushes.

No 100% coverage claim is made. Dependency-free refers to the product and tests;
Ruff and PyYAML for official validators are development-only tools.

## Evidence and hygiene

[Public validation](../benchmarks/results/2026-09-30-validation/README.md) retains
all ten runs, original numeric records, prompts, diagnostics, grading and resulting
solutions. The source archive retains the exact source files used, with ten Finder/
linter metadata files excluded. The selection manifest records the original
whole-tree hash, curated hash, retained-file hashes and omitted-file hashes. The
original whole-tree hash includes excluded files and cannot be recomputed from the
curated archive; fixture/task/evaluator hashes still match.

Workspace/home prefixes were sanitized at capture. A scan of the public evidence,
archive contents and commit candidates found no personal paths/usernames or
credential patterns. This is a pattern scan, not proof that every possible secret
format is detectable. Original local validation, copied validator tooling, previews,
bytecode, Finder metadata, virtual environments and linter caches remain excluded
from Git. No public log or recorded number was edited to remove an inconvenient outcome.

The local SVG was rendered at 960 and 720 px and inspected. It uses an opaque dark
panel with high-contrast text, so the content has the same contrast on light/dark
pages. It states that agents may inspect more files. Actual remote GitHub rendering
has not been checked on an uploaded revision.

## ContextLean dogfood

Applied the canonical Audit Context Locality and Lean Change Review workflows to
this repository/change. Bootstrap was not repeated.

| Audit area | Status and evidence |
|---|---|
| Project map, ownership and commands | PASS; current paths and verified checks, one owner per skill, benchmark parsing reused by the graded runner |
| Startup context | PASS; concise root map and one-line `@AGENTS.md` wrapper; README, evidence archives and detailed bootstrap reference are optional |
| Shared skill layout and metadata | PASS; four canonical skill directories, validated metadata and qualified discovery names |
| Exclusions and preservation | PASS; generated-only exclusions; source, fixtures, documentation, assets and useful public archives stay available |
| Documentation freshness | PASS; 0.2.0 alignment, preliminary results labelled, negative cases and installation limits visible |
| Architecture and locality | PASS; no new runtime dependency, MCP, hook, telemetry, automatic model run or speculative wrapper |
| Independent agent behavior | WARNING; complete live invocation/Claude import consumption unverified; not inferred from installation |
| Measurement strength | WARNING; one observation per task/condition, uneven CLI errors/cache noise and non-Git workspaces; no final efficiency claim |
| Remote release checks | WARNING; remote CI and clean committed-revision installation await an owner-approved commit |

Lean Change Review found a concrete hygiene issue: snapshots retained Finder and
linter metadata. Public artifacts now omit those files with an explicit selection
record, and future copies exclude them through one shared name set with an offline
regression check. No other material duplication, dead layer, dependency or misplaced
owner remains in the reviewed change. The evaluator stays outside measured workspaces;
raw artifacts and archived historical source are evidence, not additional startup guidance.

## Release scope

Ready for owner review and initial 0.2.0 release commit, with the limitations above.
Repeated benchmarks and independent paid workflow sessions are **not prerequisites**
for this scoped release and have not been authorized. They would strengthen future
claims. Remote CI and a committed-revision install check are subsequent release
verification steps. No universal performance claim, v1.0 claim or public marketplace
listing is made. See [draft release notes](release-notes.md).
