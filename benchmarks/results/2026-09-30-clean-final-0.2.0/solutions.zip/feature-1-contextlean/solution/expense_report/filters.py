def normalize_category(value):
    return value.strip().casefold()


def select_category(expenses, category):
    if category is None:
        return list(expenses)
    return [
        expense for expense in expenses
        if normalize_category(expense["category"]) == category
    ]


def select_expenses(expenses, category, min_amount=None):
    selected = select_category(expenses, category)
    if min_amount is None:
        return selected
    return [expense for expense in selected if expense["amount"] >= min_amount]
