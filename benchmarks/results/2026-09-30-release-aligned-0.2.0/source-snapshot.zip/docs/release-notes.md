# ContextLean 0.2.0 — unreleased

Both manifests and the measurement helper identify 0.2.0. This draft remains
unreleased until the owner approves tagging and publication.
[Pre-commit verification and known limits](verification.md).

- Beginner onboarding explains repository instructions, context and tokens, shows
  what bootstrap creates, and gives a five-step usage guide with a conceptual visual.
- A shared local catalog supports two-command Codex installation. Fresh Codex and
  Claude discovery exposes all four shared skills. UI prompts use qualified installed
  names, resolving the bootstrap invocation ambiguity.
- The existing bootstrap workflow remains explicit and preserves repository guidance;
  documentation explains the project map, shared Claude import and local static reports.
  Audit and review remain read-only unless their narrow fixes are separately requested.
- A dependency-free, independently graded sample suite covers navigation, bug fixes,
  features, refactors and documentation/configuration. It preserves raw outcomes,
  restores original tests and checks task acceptance in separate evaluation copies.
- Public historical evidence retains all ten earlier gpt-5.6-terra/low runs,
  including two token regressions, exact source files, solutions, diagnostics and
  calculations. One run per condition per task cannot establish statistical confidence
  or universal savings. Historical measurements retain their recorded 0.1.0 version.
- Measurement fixes distinguish turn completion from task success, keep unavailable
  fields null, avoid double-counting cached/reasoning tokens and suppress unsupported
  gain/confidence claims. Generated metadata and caches are excluded from future copies.
- Offline CI checks package/skill contracts, parsers, grading, published evidence,
  lint and formatting. The product/tests retain standard-library-only dependencies.
- ContextLean's own audit and lean review checked ownership, startup context,
  documentation, exclusions and unnecessary complexity; the snapshot hygiene issue
  was fixed without repeating bootstrap.

There is still no MCP server, hook, telemetry, runtime package or automatic model run.
Known limits include unverified full independent live skill workflows on both agents
and Claude import consumption. The new benchmark evidence commits remain local,
with their remote CI pending a future push. Benchmark CLI warnings and recovered
errors remain visible. The clean validation below used exactly ten authorized model
calls; no additional repetitions were started.

## Clean final validation evidence

The [clean final ten-run batch](../benchmarks/results/2026-09-30-clean-final-0.2.0/README.md)
passes preparation and offline regrading with the repaired harness and unchanged
product commit `52a2c34`. Both conditions succeed on all five tasks. ContextLean uses
9.9% more aggregate tokens and 17.7% more time, with one fewer command call.
Bug fix, Feature and Refactor regress on tokens/time; Navigation regresses on time;
Documentation/config improves both. No task increases command calls. These results
are preliminary, one run per condition per task, with no statistical-confidence or
universal savings claim. Historical evidence remains separate; the diagnostic batch
is invalid for headline comparison. No tag or release has been created.
