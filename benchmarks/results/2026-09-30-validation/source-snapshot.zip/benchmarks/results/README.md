# Published results

Benchmark pending. No final performance dataset is published here.

Validation batches stay in local `.contextlean/validation/` directories until their
measurement quality, fairness, task outcomes and sharing safety have been reviewed.
The initial 10-run batch is not a final benchmark. The remaining 20 runs require
user approval. Future claims must link every run and its raw evidence, including
failures and regressions, following the [benchmark guide](../README.md).
